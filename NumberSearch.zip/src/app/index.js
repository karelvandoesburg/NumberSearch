import React from 'react';
import ReactDOM from 'react-dom';
import ScreenStart from './ScreenStart';

ReactDOM.render(<ScreenStart />,document.getElementById('wrapper'));
