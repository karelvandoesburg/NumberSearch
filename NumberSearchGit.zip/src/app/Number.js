import React from 'react';

class Number extends React.Component {
  render() {
    return(
      <div className="number">
        <ul>
          <li><span style={{fontFamily:"Fira-Sans"}}>{this.props.type}</span></li>
          <li>naam: <span style={{marginLeft:40 + "px"}}>{this.props.name}</span></li>
          <li>telefoon: <span style={{marginLeft:21 + "px"}}>{this.props.phone}</span></li>
        </ul>
      </div>
    )
  }
}

module.exports = Number;
