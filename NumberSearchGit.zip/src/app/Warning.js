import React from 'react';

class Warning extends React.Component {
  render(){
    return (
      <div>Geef alstublieft meer informatie over de klant!</div>
    )
  }
}

module.exports = Warning;
