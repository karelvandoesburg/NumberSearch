import React from 'react';
import ReactDOM from 'react-dom';
import ContainerScreen from './Components/ContainerScreen';

ReactDOM.render(<ContainerScreen company="Ergatis"/>,document.getElementById('context-container'));
