import React from 'react';

class Logo extends React.Component {

  render() {
    return (
      <div id={this.props.company}></div>
    )
  }
}

export default Logo
